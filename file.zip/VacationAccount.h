#ifndef VacationAccount_h // Header guard (prevent duplicate definitions)
#define VacationAccount_h // Macro from define directive

#include "BloodDonation.h" // Include class prototype from BloodDonation.h header file to access BloodDonation type

class VacationAccount
{
public:
	// Constructor
	VacationAccount(int EmployeeID);

	// Accessor methods (getters)
	int getID();
	double getBalance();

	// Mutator methods (setters)
	bool addVacationToAccount(BloodDonation donation);

private:
	int mID;
	int mBalance = 0;
};

#endif