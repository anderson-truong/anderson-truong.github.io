Do not edit the .h files
Those are the class prototypes/declarations

Simply edit the code inside the .cpp files

Sample testing script included in main.cpp (not comprehensive)

good luck
~monkey man