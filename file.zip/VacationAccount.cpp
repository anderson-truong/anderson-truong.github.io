#include "VacationAccount.h"
// No need to include "BloodDonation.h" because already included/linked in "VacationAccount.h"

// Each method has namespace 'VacationAccount::' to reference declared methods in "VacationAccount.h" 

// Constructor
VacationAccount::VacationAccount(int EmployeeID)
{
	// Code
}

// Accessor methods (getters)
int VacationAccount::getID()
{
	// Code
	return;
}
double VacationAccount::getBalance()
{
	// Code
	return;
}

// Mutator methods (setters)
bool VacationAccount::addVacationToAccount(BloodDonation donation)
{
	// Code
	return;
}