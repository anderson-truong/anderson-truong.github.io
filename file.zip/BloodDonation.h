#ifndef BloodDonation_h // Header guard (prevent duplicate definitions)
#define BloodDonation_h // Macro from define directive

class BloodDonation
{
public:
	// Constructor
	BloodDonation(int EmployeeID, int EmployeeAge, double EmployeeWeight);

	// Accessor methods (getters)
	int getID();
	int getAge();
	double getWeight();

	// Mutator methods (setters)
	void setID(int EmployeeID);
	void setAge(int EmployeeAge);
	void setWeight(double EmployeeWeight);

private:
	int mID;
	int mAge;
	double mWeight;
};

#endif