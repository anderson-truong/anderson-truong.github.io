#include "BloodDonation.h"

// Each method has namespace 'BloodDonation::' to reference declared methods in "BloodDonation.h"

// Constructor
BloodDonation::BloodDonation(int EmployeeID, int EmployeeAge, double EmployeeWeight)
{
	// Code
}

// Accessor methods (getters)
int BloodDonation::getID()
{
	// Code
	return;
}
int BloodDonation::getAge()
{
	// Code
	return;
}
double BloodDonation::getWeight()
{
	// Code
	return;
}

// Mutator methods (setters)
void BloodDonation::setID(int EmployeeID)
{
	// Code
}
void BloodDonation::setAge(int EmployeeAge)
{
	// Code
}
void BloodDonation::setWeight(double EmployeeWeight)
{
	// Code
}