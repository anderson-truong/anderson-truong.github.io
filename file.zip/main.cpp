#include <iostream>
#include <cassert>
#include <string>
#include "BloodDonation.h"
#include "VacationAccount.h"

using namespace std;

int main()
{
    BloodDonation testDonation1{ 393849, 25, 150 };
    BloodDonation testDonation2{ 438849, 40, 200 };
    BloodDonation testDonationInvalid{ 99999, 20, 100 };
    VacationAccount testVacation{ 393849 };
    assert(testDonation1.getID() == 393849);
    assert(testDonation1.getAge() == 25);
    assert(to_string(testDonation1.getWeight()) == "150.000000");

    assert(testDonationInvalid.getID() == -1);
    assert(testDonationInvalid.getAge() == -1);
    assert(to_string(testDonationInvalid.getWeight()) == "-1.000000");

    assert(to_string(testVacation.getBalance()) == "0.000000");
    assert(testVacation.addVacationToAccount(testDonation1));
    assert(testVacation.getID() == 393849);
    assert(to_string(testVacation.getBalance()) == "4.000000");

    assert(!testVacation.addVacationToAccount(testDonation2));
    assert(to_string(testVacation.getBalance()) == "4.000000");
    cout << "cowabunga" << endl;
}